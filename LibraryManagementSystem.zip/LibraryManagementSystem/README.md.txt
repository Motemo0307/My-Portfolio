# Library Management System

## Description
The *Library Management System* is a Java console application that allows users to manage books, library members, borrowing, returning, sorting, and searching. It demonstrates core *Object-Oriented Programming (OOP) concepts* including:

- Encapsulation  
- Inheritance  
- Information hiding  
- Polymorphism  

The application is designed for learning OOP principles and building a complete Java project.

---

## Features
- Add new books with Book ID, title, and author  
- Borrow and return books  
- View all books with status (Available/Borrowed) and library summary  
- Sort books by *Title* or *Author*  
- Search for books by *Title* or *Author* keyword  
- Automatically resizes the book array when capacity is reached  

---

## Technologies Used
- Java  
- NetBeans IDE (optional)  
- Git/GitHub for version control  

---

## How to Run
1. Clone this repository:
   ```bash
   git clone <your-repo-url>
2. Open the project in your IDE (NetBeans, IntelliJ, or VSCode).


3. Compile and run the main class:

LibraryApp.java


4. Use the menu to navigate the library system:

1. Add Book
2. Borrow Book
3. Return Book
4. View All Books
5. Sort Books
6. Search Book
7. Exit

---

## Thank You
Thank you for checking out my project. I hope you find it useful and well-structured!

